Create a non-empty file called
/home/chal8/secret/directory/contains/nonempty_file
then run ~/check_file.sh

Note: Quickly write something to a file with the echo-command
and output redirection (e.g. echo content > new_file.txt).

commands: mkdir, echo
