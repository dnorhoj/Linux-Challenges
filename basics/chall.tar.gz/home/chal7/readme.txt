Create an empty file called
/home/chal7/secret/directory/contains/empty_file
then run ~/check_file.sh

commands: mkdir, touch
