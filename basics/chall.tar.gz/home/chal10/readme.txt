To solve this challenge, you must make sure 
/home/chal10/secret/ does not exist then run ~/check_file.sh

Removing files and directories separately with rm and rmdir
can get really old. Check the manual page for rm to find an
easier way.

commands: man, rm
