In this challenge you need to look for a hidden file
to find the password.
