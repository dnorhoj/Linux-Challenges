Congratulations! You have solved the challenges.
