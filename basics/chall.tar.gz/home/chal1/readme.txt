The password for the next level is
L8r8Nfq9Co1KAQWW50iTLp6z

Use the command
su - chal2
to continue to the next level

