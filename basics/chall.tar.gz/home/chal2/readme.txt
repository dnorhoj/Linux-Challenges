In this challenge you need find the password in a
file in the secret-directory.

commands: cd, ls, cat
