To solve this challenge you need to run the script run_me.sh
in the current users home directory.

Remember: For scripts/executables that are not in the PATH,
you need to provide a path (absolute or relative)
