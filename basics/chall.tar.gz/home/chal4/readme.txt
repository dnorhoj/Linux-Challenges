To solve this challenge you should use tabcompletion.
see https://web.stanford.edu/class/archive/cs/cs107/cs107.1196/resources/tab

The solution is in a file somewhere under sec.../y../sh.../

commands: cd, cat
