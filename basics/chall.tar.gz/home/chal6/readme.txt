This time you need to run a script with the argument "sesame"
