To solve this challenge, you must make sure 
/home/chal9/secret/ does not exist then run ~/check_file.sh

commands: rm, rmdir
